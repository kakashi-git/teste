<div class="titulo">Variáveis Variáveis</div>


<?php

$a = 'valorA';
$$a = 'valorAA';


$valorA = 'valorAA';
echo "$a {$$a} ${$a} $valorA";

echo '<br>';
$epa = '<br>opa';
$opa = '<br>vish';
$vish = '<br>eita!!!!';
echo "$epa {$$epa} {$$$epa}";









?>
