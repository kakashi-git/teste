<div class="titulo">Desafio Variáveis</div>


<?php

$a = 'Nossa!';
$Nossa = 'Eu';
$Eu = 'Consegui';
$Responder = 'Esse';
$Esse = 'Desafio';

echo "Nossa! Eu consegui responder esse desafio.";

// $a


echo "<br>";
echo "{$a} {$Nossa} {$Eu} responder {$Responder} {$Esse}!" ;








?>