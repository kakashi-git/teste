<div class="titulo">Variáveis</div>

<?php
 echo 'Variáveis';
 echo '<br>';



$numeroA = 13;
echo $numeroA, '<br>';
var_dump($numeroA);

echo '<br>';
$a = 17;
$b = 90;
$somadosnumeros = $a + $b;
echo $somadosnumeros;

echo '<br>';

echo isset ($somadosnumeros);

echo '<br>';
unset($somadosnumeros);
var_dump($somadosnumeros);


$variavel = 10;
echo '<br>';

$variavel = "agora sou uma string!";
echo '<br>' . $variavel;


// nomes de variaveis

$var = 'valida';
$var2 = 'valida';
$var3 = 'valida';
$var_var_4 = 'valida';

echo '<br>';
var_dump($_SERVER["SERVER_NAME"]);
echo '<br>';





?>