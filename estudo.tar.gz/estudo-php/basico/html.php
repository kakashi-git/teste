<div class="titulo">Integração HTML</div>

<h1>
<?php
echo 'Olá';
echo '<small>';
echo ' Mundo!';
echo '</small>';

?>
</h1>