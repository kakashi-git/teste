<div class="titulo" center>Integração CSS</div>

<h1 center>
<?php
echo 'Olá';
echo '<small>';
echo ' Mundo!';
echo '</small>';

?>
</h1>

<br>
   

<div center><button dobro><a href="http://localhost:8080/estudo-php/index.php"><?= "legal"?></a></button></div>

<style>
    button {
        font-size: 1.20rem;
        padding: 5px 20px;
        background-color: #4286f4;
        color: #EEE;
        font-weight; bold;
        border-radius: 10px;
    }
    [center] {
        display: flex;
        justify-content: center;
    }

    [azul] {
        color:  #4286f4
    }
    [dobro] {
        font-size: 2rem;
    }


</style>