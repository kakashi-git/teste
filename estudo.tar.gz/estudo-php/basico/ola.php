<div class="titulo">Olá PHP</div>

<?php
echo 'Olá <br> ';
echo 'Mundo!';
 ?>


 <?= "teste" ?>


 <?php
 phpinfo();