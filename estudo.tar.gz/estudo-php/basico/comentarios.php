<div class="titulo">Comentários PHP</div>

<?php
echo "Estou no PHP";
echo "comentario";

?>