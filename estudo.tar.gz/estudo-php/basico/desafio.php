<div class="titulo">Desafio</div>
<ul>
    <li>1 + 1 = <?=1 + 1 ?></li>
    <li>4 + 4 = <?=4 + 4 ?></li>
    <li>8 + 8 = <?=8 + 8 ?></li>
</ul>