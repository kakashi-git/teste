<div class="titulo">Downloads</div>

    <link href="https://fonts.googleapis.com/css2?family=Staatliches&display=swap" rel="stylesheet">
	<link href="http://localhost/estudo-php/exercicio.php?dir=basico&file=downloadss" rel="stylesheet"/>
	<link href="http://localhost/estudo-php/exercicio.php?dir=basico&file=downloads" rel="stylesheet"/>


<?php

echo '<h2>DOWNLOADS:<h2>';
?>

<div class="downloads">
<button>
<a href="http://localhost/Downloads/estudo-php.tar.gz"><h3> ESTUDO PHP 10 / 11 / 2020 <h3></a>
</button>

</div>
<style>
.titulo {

    text-align: center;
}
.downloads {
    text-align: center;
}

   button  {
        color: white;
        font-size: 1rem;
        padding: 1px 10px;
        background-color: #4d4c4c;
        border-radius: 10px;
        box-shadow: -1px 0px 9px 0px rgba(0,0,0,0.25);
        
    }

    a:link 
{ 
 text-decoration:white; 
 
 
} 

h3 {
    color: rgb(241, 239, 239);
    text-align: center;
}
h2 {
    text-align: center;
    
}

</style>
<div class="downloads">
<button>
<a href="http://localhost/Downloads/estudo-php.tar.gz"><h3> ESTUDO PHP 10 / 11 / 2020 <h3></a>
</button>

</div>
<style>
    button  {
        color: white;
        font-size: 1rem;
        padding: 1px 10px;
        background-color: #4d4c4c;
        border-radius: 10px;
        box-shadow: -1px 0px 9px 0px rgba(0,0,0,0.25);
    }

    a:link 
{ 
 text-decoration:white; 
 
} 

h3 {
    color: rgb(241, 239, 239);
}


</style>
<style>
    button  {
        color: white;
        font-size: 1rem;
        padding: 1px 10px;
        background-color: #4d4c4c;
        border-radius: 10px;
        box-shadow: -1px 0px 9px 0px rgba(0,0,0,0.25);
       
    }

    a:link 
{ 
 text-decoration:white; 
 
} 

h3 {
    color: rgb(241, 239, 239);
}


</style>
<div class="downloads">
<button>
<a href="http://localhost/Downloads/estudo-php.tar.gz"><h3> ESTUDO PHP 10 / 11 / 2020 <h3></a>
</button>

</div>
<style>
    button  {
        color: white;
        font-size: 1rem;
        padding: 1px 10px;
        background-color: #4d4c4c;
        border-radius: 10px;
        box-shadow: -1px 0px 9px 0px rgba(0,0,0,0.25);
        text-align: center;
    }

    a:link 
{ 
 text-decoration:white; 
 
} 

h3 {
    color: rgb(241, 239, 239);
}




</style>
