<div class="titulo">Operadores lógicos</div>

<?php

var_dump(true);
echo '<br>';
var_dump(!!true);

echo '<p>Valores pode ser V ou F</p><hr>';
var_dump(!!5);
var_dump(!!0);
var_dump(!!"");

echo "<p>Tabela verdade 'AND' (E)</p><hr>";

var_dump(true && true);
echo '<br>';
var_dump(true && false);
echo '<br>';
var_dump(false && true);
echo '<br>';
var_dump(false && false);
echo '<br>';
var_dump(true && 3 > 2 && 7 <= 7);
echo '<br>';
echo"<p></P><hr>";
var_dump(true and true);
echo '<br>';
var_dump(true and false);
echo '<br>';
var_dump(false and true);
echo '<br>';
var_dump(false and false);
echo '<br>';
var_dump(true and 3 > 2 && 7 <= 7);
echo '<br>';


echo "<p>Tabela verdade 'OR' (OU)</p><hr>";
var_dump(true || true);
echo '<br>';
var_dump(true || false);
echo '<br>';
var_dump(false || true);
echo '<br>';
var_dump(false || false);
echo '<br>';

echo '<p></p><hr>';

var_dump(true or true);
echo '<br>';
var_dump(true or false);
echo '<br>';
var_dump(false or true);
echo '<br>';
var_dump(false or false);
echo '<br>';

echo "<p>Tabela verdade 'OR' (OU)</p><hr>";
var_dump(true xor true);
echo '<br>';
var_dump(true xor true);
echo '<br>';
var_dump(true xor true);
echo '<br>';
var_dump(true xor true);
echo '<br>';
var_dump(true xor true);
echo '<br>';
echo "<p class='divisao'>EXEMPLO</p><hr>";

$idade = 40;
$sexo = 'F';


if( $sexo === 'M'){
    echo 'SEXO MASCULINO' . '<br>';
} elseif ($sexo === 'F'){
    echo 'SEXO FEMININO' . '<br>';
}



$pagouPrevidencia = true;
$criterioHomem = ($idade >= 65 && $sexo === 'M');
$criterioMulher = ($idade >= 60 && $sexo === 'F');
$atingiuCriterio = $criterioHomem | $criterioMulher;
$podeSeAposentar = $pagouPrevidencia && $atiginiuCriterio;
//echo "Pode se aposentar -> $podeSeAposentar.<br>";



if($idade >= 60 && $sexo === 'F') {
    echo 'Pode se aposentar';
} elseif ($idade >= 65 && $sexo === 'M') {
    echo "Pode se aposentar ";
} else {
    echo 'Vai ter que trabalhar mais um pouco...';
}






?>

<style>
p {
    margin-bottom: 0px;
    font-weight: bold;
}

hr {
    margin-top: 0px;
}
</style>