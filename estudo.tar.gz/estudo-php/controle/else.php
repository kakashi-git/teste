<div class="titulo">Else</div>

<?php

if(true) {
    echo "sentença avulsa!!!" . '<br>';
}



if(false) {

} else {
    if(false) {
    } else {
        //ponto
        echo "AQUI" . '<br>';
    }
}




if(true) {
    echo "Verdadeiro - Parte A" . '<br>';
    echo "Verdadeiro - Parte B" . '<br>';
} else {
    echo "Falso - Parte A" . '<br>';
    echo "Falso - Parte B" . '<br>';
}


if(false) {
    echo "Passo A" . '<br>';
} else if(false) {   
    echo "Passo B" . '<br>';
} else if(true) {   
    echo "Passo C" . '<br>';
} else {
    echo "Ùltimo passo" . '<br>';
}

echo "Fim" . '<br>';

?>