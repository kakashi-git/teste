<div class="titulo">Operadores relacionais</div>

<?php 


var_dump (1 == 1); echo '<br>';
var_dump (1 > 1); echo '<br>';
var_dump (1 == 1); echo '<br>';
var_dump (1 >=1); echo '<br>';
var_dump (1 <>1); echo '<br>';
var_dump (1 ==1); echo '<br>';
var_dump (1 ==1); echo '<br>';

echo "<p>Relacionais no IF/ELSE</p><hr>";

$idade = 300;

if($idade > 200){
    echo "Èrico Ancião" .'<br>';
}
if($idade < 18) {
    echo "Pentelho = $idade" .'<br>';
} else if($idade <= 65) {
    echo "Coroa = $idade" . '<br>';
} else {
    echo "Velho = $idade"  . '<br>';
} 

/////////////////////////////////////////

echo '<p>SPACESHIP</p><hr>';


var_dump(500 <=> 3);
var_dump(50 <=> 50);
var_dump(5 <=> 50);
?>

<style>
p {
    margin-bottom: 0px;
}

hr {
    margin-top: 0px;
}

</style>