<div class="titulo">Desafio PI PHP</div>

<?php

echo pi();
$pi = 3.14;

if($pi === pi()) {
    echo "<br>Iguais";
} else {
    echo "<br>Diferentes";
}

//Operador relaiconal
$piERRADO = 2.8;


//Resposta

echo '<br>' . ($pi - pi());
echo '<br>' . ($pi - $pierrado);

if($pi - pi() <= 0.01) {
    echo '<br>Praticamente iguais!';

}

if($pi - $piERRADO <= 0.01) {
    echo '<br>Valor errado';
    
} 

?> 