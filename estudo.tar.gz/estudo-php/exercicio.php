<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="shortcut icon" href="http://localhost/estudo-php/content/favicon.ico" />
	<link href="https://fonts.googleapis.com/css2?family=Staatliches&display=swap" rel="stylesheet">
	<link href="http://localhost:80/estudo-php/assets/css/estilo.css" rel="stylesheet"/>
	<link href="http://localhost:80/estudo-php/assets/css/exercicio.css" rel="stylesheet"/>

	<title>Exercício</title>
</head>
<body class="exercicio">
	<header class="cabecalho">

	<?php

				 echo '<h1>Curso PHP</h1><br>
				 <h2>
				 Ídice dos Exercícios</h2>', '<br>';

				 ?>




		<!--<h1>Curso PHP</h1>
		<h2>Visualizacão do Exercício</h2>-->
	</header>
	<nav class="navegacao">
		<a href="exercicio.php?dir=calculadora&file=calculadora" target="_blank" class="azul">calculadora</a> 
		<a href=<?="{$_GET['dir']}/{$_GET['file']}.php"?> class="verde">Sem formatação</a>
		<a href="index.php" class="vermelho">Voltar</a> 
		<a href="http://localhost/estudo-php/exercicio.php?dir=basico&file=downloads" class="amarelo">Downloads</a> 
		
		
	</nav>
	<main class="principal">
		<div class="conteudo">
			<?php

				 include(__DIR__ ."/{$_GET['dir']}/{$_GET['file']}.php");
				 //include('teste/teste.php')
				//include($_GET['dir'] . "/" . $_GET['file'] . ".php");
				 //echo 'Olá PHP'

				// include(__DIR__ . "/{$_GET['dir']}/{$_GET['file']}.php");

			?>

		</div>
	</main>

	<footer class="rodape">
	<div>
		<a href="https://www.cod3r.com.br/">	
				<img src="content/cod3r.png" width=150 height=30>
			
		</a>
	</div>
	</footer>
</body>
</html>