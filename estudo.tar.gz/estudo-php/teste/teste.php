<?php
echo("Olá PHP");
?>