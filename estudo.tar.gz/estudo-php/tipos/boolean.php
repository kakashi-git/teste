<div class="titulo">Boolean</div>

<?php

echo TRUE . '<br>';
echo FALSE . '<br>';

var_dump(true);
echo'<br>';

var_dump(false);
echo'<br>';
var_dump('false');
echo'<br>';

echo '<br>' . is_bool('true');
echo '<br>' . is_bool(false);



// Fazer as regras de conversões

echo '<p>Regras:</p>';
echo '<br>' . var_dump((bool) 0); // Apenas zero é false
echo '<br>' . var_dump((bool) 20);
echo '<br>' . var_dump((bool) -1);
echo '<br>' . var_dump((bool) 0.0);
echo '<br>' . var_dump((bool) 0.0000000000000);
echo '<br>' . var_dump((bool) ""); // false
echo '<br>' . var_dump((bool) "0"); // false
echo '<br>' . var_dump((bool) " "); // todo o resto é true
echo '<br>' . var_dump((bool)"00"); // 
echo '<br>' . var_dump((bool) "false");














?>