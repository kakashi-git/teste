<div class="titulo">Desafio String</div>

<?php

Echo 'Desafio string' . '<br>';


// Enunciado:
// Avaliando os métodos de documentação de string,
// qual o método que a posição do texto 'abc'
// na string 'AbcaBcabc' retorne 1?



echo '<br>' . substr('AbcaBcabc', 0, 3) . '<br>'; 
var_dump ('AbcaBcabc');

echo '<br>' . strlen('AbcaBcabc') . '<br>';

echo strpos('!AbcaBcabc', 'abc') . '<br>';
echo stripos('!AbcaBcabc', 'abc') . '<br>';
echo strpos(strtolower('!AbcaBcabc'), strtolower('ABC'));


?>