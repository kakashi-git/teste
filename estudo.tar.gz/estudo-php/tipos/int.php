<div class="titulo">Tipo Inteiro</div>

<?php
echo 11;
echo '<br>';

var_dump(11);
echo '<br>';

echo PHP_INT_MAX, '<br>';
echo PHP_INT_MIN, '<br>';
echo 017, '<br>'; //base octal
echo 0b11, '<br>'; //base binaria
echo 0x11117acbf0; //exadecimal